
#include <iostream>
#include "openfhe.h"

#include "ciphertext-ser.h"
#include "scheme/ckksrns/ckksrns-ser.h"
#include "ciphertext-ser.h"
#include "cryptocontext-ser.h"
#include "key/key-ser.h"
#include <thread>

#include "Utils.h"
#include <fstream>  


using namespace lbcrypto;
using namespace std;
using namespace utils;

using Ptxt = Plaintext;               
using Ctxt = Ciphertext<DCRTPoly>;      

int generate_context;
int verbose;   
string input_filename;

void check_arguments(int argc, char *argv[]);


class FHEController 
{
    CryptoContext<DCRTPoly> context;

public:
    int circuit_depth;
    int num_slots;

    FHEController() {}

 
    void generate_context(int log_ring, int log_scale, int log_primes, int digits_hks, int cts_levels, int stc_levels, int relu_degree, bool serialize = false);
    void load_context(bool verbose = true);


    void generate_bootstrapping_keys(int bootstrap_slots);
    void generate_rotation_keys(vector<int> rotations, bool serialize = false, string filename = "");
    void generate_bootstrapping_and_rotation_keys(vector<int> rotations,int bootstrap_slots,bool serialize,const string& filename);

    void load_bootstrapping_and_rotation_keys(const string& filename, int bootstrap_slots, bool verbose);
    void load_rotation_keys(const string& filename, bool verbose);
    void clear_bootstrapping_and_rotation_keys(int bootstrap_num_slots);
    void clear_rotation_keys();
    void clear_context(int bootstrapping_key_slots);

 
    Ptxt encode(const vector<double>& vec, int level, int plaintext_num_slots);
    Ptxt encode(double val, int level, int plaintext_num_slots);
    Ctxt encrypt(const vector<double>& vec, int level = 0, int plaintext_num_slots = 0);
    Ctxt encrypt_ptxt(const Ptxt& p);
    Ptxt decrypt(const Ctxt& c);
    vector<double> decrypt_tovector(const Ctxt& c, int slots);


    Ctxt add(const Ctxt& c1, const Ctxt& c2);
    Ctxt mult(const Ctxt& c, double d);
    Ctxt mult(const Ctxt& c, const Ptxt& p);
    Ctxt bootstrap(const Ctxt& c, bool timing = false);
    Ctxt bootstrap(const Ctxt& c, int precision, bool timing = false);
    Ctxt relu(const Ctxt& c, double scale, bool timing = false);
    Ctxt relu_wide(const Ctxt& c, double a, double b, int degree, double scale, bool timing = false);
    
    
    
    string parameters_folder = "NO_FOLDER";
    int relu_degree = 2;

    private:
    KeyPair<DCRTPoly> key_pair;
    vector<uint32_t> level_budget = {4, 4}; 
};


void FHEController::generate_context(int log_ring, int log_scale, int log_primes, int digits_hks, int cts_levels,
                                     int stc_levels, int relu_degree, bool serialize) 
{
    CCParams<CryptoContextCKKSRNS> parameters;

    num_slots = 1 << 14;    
    
    parameters.SetSecretKeyDist(SPARSE_TERNARY);   
    parameters.SetSecurityLevel(lbcrypto::HEStd_128_classic);
    parameters.SetNumLargeDigits(digits_hks);        
    parameters.SetRingDim(1 << log_ring);          
    parameters.SetBatchSize(num_slots);

    level_budget = vector<uint32_t>();          

    level_budget.push_back(cts_levels);           
    level_budget.push_back(stc_levels);          

    int dcrtBits = log_primes;                   
    int firstMod = log_scale;                    

    parameters.SetScalingModSize(dcrtBits);
    parameters.SetScalingTechnique(FLEXIBLEAUTO);   
    parameters.SetFirstModSize(firstMod);

    uint32_t approxBootstrapDepth = 4 + 4; 

    uint32_t levelsUsedBeforeBootstrap = relu_degree + 3;   
     
    circuit_depth = levelsUsedBeforeBootstrap +
                    FHECKKSRNS::GetBootstrapDepth(approxBootstrapDepth, level_budget, SPARSE_TERNARY);   


    cout << endl << "Ciphertext multiplicative depth:" << circuit_depth << ", Supported multiplicative depth: "<< levelsUsedBeforeBootstrap - 2 << endl;

    parameters.SetMultiplicativeDepth(circuit_depth);

    context = GenCryptoContext(parameters);  

    cout << "Context built, generating keys..." << endl;

    context->Enable(PKE);         
    context->Enable(KEYSWITCH);    
    context->Enable(LEVELEDSHE);  
    context->Enable(ADVANCEDSHE);  
    context->Enable(FHE);          

    key_pair = context->KeyGen();       

    context->EvalMultKeyGen(key_pair.secretKey);   

    cout << "Generated." << endl;


    ofstream multKeyFile("../" + parameters_folder + "/mult-keys.txt", ios::out | ios::binary);
    if (multKeyFile.is_open()) 
    {
        if (!context->SerializeEvalMultKey(multKeyFile, SerType::BINARY))  
        {
            cerr << "Failed to save multiplication keys." << std::endl;
            exit(1);
        }
        cout << "Multiplication keys saved successfully." << std::endl;
        multKeyFile.close();
    } else {
        cerr << "Error serializing EvalMult keys in \"" << "../" + parameters_folder + "/mult-keys.txt" << "\"" << endl;
        exit(1);
    }

    if (!Serial::SerializeToFile("../" + parameters_folder + "/crypto-context.txt", context, SerType::BINARY)) {
        cerr << "Failed to write the encryption context to crypto-context.txt." << endl;
    } else {
        cout << "Encryption context saved successfully." << std::endl;
    }

    if (!Serial::SerializeToFile("../" + parameters_folder + "/public-key.txt", key_pair.publicKey, SerType::BINARY)) {
        cerr << "Failed to write the public key to public-key.txt." << endl;
    } else {
        cout << "Public key saved successfully." << std::endl;
    }

    if (!Serial::SerializeToFile("../" + parameters_folder + "/secret-key.txt", key_pair.secretKey, SerType::BINARY)) {
        cerr << "Failed to write the secret key to 'secret-key.txt'." << endl;
    } else {
        cout << "Secret key saved successfully." << std::endl;
    }

}

void FHEController::load_context(bool verbose) {
    context->ClearEvalMultKeys();                  
    context->ClearEvalAutomorphismKeys();

    CryptoContextFactory<lbcrypto::DCRTPoly>::ReleaseAllContexts();

    if (verbose) cout << "Starting to read the context..." << endl;

    if (!Serial::DeserializeFromFile("../" + parameters_folder + "/crypto-context.txt", context, SerType::BINARY)) 
    {
        cerr << "I cannot read serialized data from: " << "../" + parameters_folder + "/crypto-context.txt" << endl;
        exit(1);
    }

    PublicKey<DCRTPoly> clientPublicKey;
    if (!Serial::DeserializeFromFile("../" + parameters_folder + "/public-key.txt", clientPublicKey, SerType::BINARY)) {
        cerr << "I cannot read serialized data from public-key.txt" << endl;
        exit(1);
    }

    PrivateKey<DCRTPoly> serverSecretKey;
    if (!Serial::DeserializeFromFile("../" + parameters_folder + "/secret-key.txt", serverSecretKey, SerType::BINARY)) {
        cerr << "I cannot read serialized data from public-key.txt" << endl;
        exit(1);
    }

    key_pair.publicKey = clientPublicKey;
    key_pair.secretKey = serverSecretKey;

    std::ifstream multKeyIStream("../" + parameters_folder + "/mult-keys.txt", ios::in | ios::binary);
    if (!multKeyIStream.is_open()) {
        cerr << "Cannot read serialization from " << "mult-keys.txt" << endl;
        exit(1);
    }
    if (!context->DeserializeEvalMultKey(multKeyIStream, SerType::BINARY)) {
        cerr << "Could not deserialize eval mult key file" << endl;
        exit(1);
    }


    relu_degree = stoi(read_from_file("../" + parameters_folder + "/relu_degree.txt"));


    level_budget[0] = read_from_file("../" + parameters_folder + "/level_budget.txt").at(0) - '0';
    level_budget[1] = read_from_file("../" + parameters_folder + "/level_budget.txt").at(2) - '0';

    if (verbose) cout << "CtoS: " << level_budget[0] << ", StoC: " << level_budget[1] << endl;

    uint32_t approxBootstrapDepth = 4 + 4;  

    uint32_t levelsUsedBeforeBootstrap = get_relu_depth(relu_degree) + 3;

    circuit_depth = levelsUsedBeforeBootstrap + FHECKKSRNS::GetBootstrapDepth(approxBootstrapDepth, level_budget, SPARSE_TERNARY);

    if (verbose) cout << "Circuit depth: " << circuit_depth << ", available multiplications: " << levelsUsedBeforeBootstrap - 2 << endl;

    num_slots = 1 << 14;    
}

void FHEController::generate_bootstrapping_keys(int bootstrap_slots) 
{
    context->EvalBootstrapSetup(level_budget, {0, 0}, bootstrap_slots);
    context->EvalBootstrapKeyGen(key_pair.secretKey, bootstrap_slots);
}

void FHEController::generate_rotation_keys(vector<int> rotations, bool serialize, std::string filename) {
    if (serialize && filename.size() == 0) {
        cout << "Filename cannot be empty when serializing rotation keys." << endl;
        return;
    }

    context->EvalRotateKeyGen(key_pair.secretKey, rotations);

    if (serialize) {
        ofstream rotationKeyFile("../" + parameters_folder + "/rot_" + filename, ios::out | ios::binary);
        if (rotationKeyFile.is_open()) {
            if (!context->SerializeEvalAutomorphismKey(rotationKeyFile, SerType::BINARY)) {
                cerr << "Error writing rotation keys" << std::endl;
                exit(1);
            }
            cout << "Rotation keys \"" << filename << "\" have been serialized" << std::endl;
        } else {
            cerr << "Error serializing Rotation keys" << "../" + parameters_folder + "/rot_" + filename << std::endl;
            exit(1);
        }
    }
}


void FHEController::generate_bootstrapping_and_rotation_keys(vector<int> rotations, int bootstrap_slots, bool serialize, const string& filename) {
    if (serialize && filename.empty()) {
        cout << "Filename cannot be empty when serializing bootstrapping and rotation keys." << endl;
        return;
    }

    generate_bootstrapping_keys(bootstrap_slots);
    generate_rotation_keys(rotations, serialize, filename);
}

void FHEController::load_bootstrapping_and_rotation_keys(const string& filename, int bootstrap_slots, bool verbose) {
    if (verbose) cout << endl << "Loading bootstrapping and rotations keys from " << filename << "..." << endl;

    auto start = start_time();

    context->EvalBootstrapSetup(level_budget, {0, 0}, bootstrap_slots);

    if (verbose)  cout << "(1/2) Bootstrapping precomputation completed!" << endl;


    ifstream rotKeyIStream("../" + parameters_folder + "/rot_" + filename, ios::in | ios::binary);
    if (!rotKeyIStream.is_open()) {
        cerr << "Cannot read serialization from " << "../" + parameters_folder + "/" << "rot_" << filename << std::endl;
        exit(1);
    }

    if (!context->DeserializeEvalAutomorphismKey(rotKeyIStream, SerType::BINARY)) {
        cerr << "Could not deserialize eval rot key file" << std::endl;
        exit(1);
    }

    if (verbose) cout << "(2/2) Rotation keys have been read." << endl;

    if (verbose) print_duration(start, "Loading bootstrapping pre-computations + rotations");

    if (verbose) cout << endl;
}

void FHEController::load_rotation_keys(const string& filename, bool verbose) {
    if (verbose) cout << endl << "Loading rotations keys from " << filename << "..." << endl;

    auto start = start_time();

    ifstream rotKeyIStream("../" + parameters_folder + "/rot_" + filename, ios::in | ios::binary);
    if (!rotKeyIStream.is_open()) {
        cerr << "Cannot read serialization from " << "../" + parameters_folder + "/" << "rot_" << filename << std::endl;
        exit(1);
    }

    if (!context->DeserializeEvalAutomorphismKey(rotKeyIStream, SerType::BINARY)) {
        cerr << "Could not deserialize eval rot key file" << std::endl;
        exit(1);
    }

    if (verbose) {
        cout << "(1/1) Rotation keys read!" << endl;
        print_duration(start, "Loading rotation keys");
        cout << endl;
    }
}

void FHEController::clear_bootstrapping_and_rotation_keys(int bootstrap_num_slots) {

    
    clear_rotation_keys();
}

void FHEController::clear_rotation_keys() {
    context->ClearEvalAutomorphismKeys();
}

void FHEController::clear_context(int bootstrapping_key_slots) {
    if (bootstrapping_key_slots != 0)
        clear_bootstrapping_and_rotation_keys(bootstrapping_key_slots);
    else
        clear_rotation_keys();

    context->ClearEvalMultKeys();
}


Ptxt FHEController::encode(const vector<double> &vec, int level, int plaintext_num_slots) {
    if (plaintext_num_slots == 0) {
        plaintext_num_slots = num_slots;
    }

    Ptxt p = context->MakeCKKSPackedPlaintext(vec, 1, level, nullptr, plaintext_num_slots);
    p->SetLength(plaintext_num_slots);
    return p;
}

Ptxt FHEController::encode(double val, int level, int plaintext_num_slots) {
    if (plaintext_num_slots == 0) {
        plaintext_num_slots = num_slots;
    }

    vector<double> vec;
    for (int i = 0; i < plaintext_num_slots; i++) {
        vec.push_back(val);
    }

    Ptxt p = context->MakeCKKSPackedPlaintext(vec, 1, level, nullptr, plaintext_num_slots);
    p->SetLength(plaintext_num_slots);
    return p;
}


Ctxt FHEController::encrypt(const vector<double> &vec, int level, int plaintext_num_slots) {
    if (plaintext_num_slots == 0) {
        plaintext_num_slots = num_slots;
    }

    Ptxt p = encode(vec, level, plaintext_num_slots);

    return context->Encrypt(p, key_pair.publicKey);
}

Ctxt FHEController::encrypt_ptxt(const Ptxt& p) {
    return context->Encrypt(p, key_pair.publicKey);
}


Ptxt FHEController::decrypt(const Ctxt &c) {
    Ptxt p;
    context->Decrypt(key_pair.secretKey, c, &p);
    return p;
}

vector<double> FHEController::decrypt_tovector(const Ctxt &c, int slots) {
    if (slots == 0) {
        slots = num_slots;
    }

    Ptxt p;
    context->Decrypt(key_pair.secretKey, c, &p);
    p->SetSlots(slots);
    p->SetLength(slots);
    vector<double> vec = p->GetRealPackedValue();
    return vec;
}


Ctxt FHEController::add(const Ctxt &c1, const Ctxt &c2) {
    return context->EvalAdd(c1, c2);
}


Ctxt FHEController::mult(const Ctxt &c1, double d) {
    Ptxt p = encode(d, c1->GetLevel(), num_slots);
    return context->EvalMult(c1, p);
}

Ctxt FHEController::mult(const Ctxt &c, const Ptxt& p) {
    return context->EvalMult(c, p);
}

Ctxt FHEController::bootstrap(const Ctxt &c, bool timing) {
    if (static_cast<int>(c->GetLevel()) + 2 < circuit_depth && timing) {
        cout << "You are bootstrapping with remaining levels! You are at " << to_string(c->GetLevel()) << "/" << circuit_depth - 2 << endl;
    }


    auto start = start_time();

    Ctxt res = context->EvalBootstrap(c);

    if (timing) {
        print_duration(start, "Bootstrapping " + to_string(c->GetSlots()) + " slots");
    }

    cout<< "Bootstrapping completed. Remaining levels:"<<to_string(res->GetLevel())<<endl<<endl;

    return res;
}

Ctxt FHEController::bootstrap(const Ctxt &c, int precision, bool timing) {
    if (static_cast<int>(c->GetLevel()) + 2 < circuit_depth) {
        cout << "You are bootstrapping with remaining levels! You are at " << to_string(c->GetLevel()) << "/" << circuit_depth - 2 << endl;
    }

    auto start = start_time();

    Ctxt res = context->EvalBootstrap(c, 2, precision);

    if (timing) {
        print_duration(start, "Double Bootstrapping " + to_string(c->GetSlots()) + " slots");
    }

    return res;
}


Ctxt FHEController::relu(const Ctxt &c, double scale, bool timing) {
    auto start = start_time();


    Ptxt result;
    context->Decrypt(key_pair.secretKey, c, &result);
    vector<double> v = result->GetRealPackedValue();



    Ctxt res = context->EvalChebyshevFunction([scale](double x) -> double { if (x < 0) return 0; else return (1 / scale) * x; }, c,
                                              -1,
                                              1, relu_degree);

    if (timing) {
        print_duration(start, "ReLU d = " + to_string(relu_degree) + " evaluation");
    }

    return res;
}

Ctxt FHEController::relu_wide(const Ctxt &c, double a, double b, int degree, double scale, bool timing) {
    auto start = start_time();


    Ptxt result;
    context->Decrypt(key_pair.secretKey, c, &result);
    vector<double> v = result->GetRealPackedValue();

    cout << "min: " << *min_element(v.begin(), v.end()) << ", max: " << *max_element(v.begin(), v.end()) << endl;


    Ctxt res = context->EvalChebyshevFunction([scale](double x) -> double { if (x < 0) return 0; else return (1 / scale) * x; }, c,
                                              a,
                                              b, degree);
    if (timing) {
        print_duration(start, "ReLU d = " + to_string(degree) + " evaluation");
    }

    return res;
}

FHEController controller;

void check_arguments(int argc, char *argv[]) {
    generate_context = -1;
    verbose = 0;

    for (int i = 1; i < argc; ++i) {

        if (string(argv[i]) == "verbose") {
            if (i + 1 < argc) { 
                verbose = atoi(argv[i + 1]);
            }
        }
    }


    for (int i = 1; i < argc; ++i) {
        if (string(argv[i]) == "load_keys") {
            if (i + 1 < argc) {
                controller.parameters_folder = "keys_exp" + string(argv[i + 1]);
                if (verbose > 1) cout << "Context folder set to: \"" << controller.parameters_folder << "\"." << endl;
                generate_context = 0;
            }
        }


        if (string(argv[i]) == "generate_keys") {
            if (i + 1 < argc) {
                string folder = "";
                if (string(argv[i+1]) == "1") {
                    folder = "keys_exp1";
                    generate_context = 1;
                } else if (string(argv[i+1]) == "2") {
                    folder = "keys_exp2";
                    generate_context = 2;
                } else {
                    cerr << "Set a proper value for 'generate_keys'." << endl;
                    exit(1);
                }

                controller.parameters_folder = folder;
                if (verbose > 1) cout << "Context folder set to: \"" << controller.parameters_folder << "\"." << endl;
            }
        }

        if (string(argv[i]) == "input") {
            if (i + 1 < argc) {
                input_filename = "../" + string(argv[i + 1]);
                if (verbose > 1) cout << "Input image set to: \"" << input_filename << "\"." << endl;
            }
        }


    }

}

void print_moduli_chain(const DCRTPoly& poly){
    int num_primes = poly.GetNumOfElements();
    double total_bit_len = 0.0;
    for (int i = 0; i < num_primes; i++) {
        auto qi = poly.GetParams()->GetParams()[i]->GetModulus();
        std::cout << "q_" << i << ": " 
                    << qi
                    << ",  log q_" << i <<": " << log(qi.ConvertToDouble()) / log(2)
                    << std::endl;
        total_bit_len += log(qi.ConvertToDouble()) / log(2);
    }   
    std::cout << "Total bit length: " << total_bit_len << std::endl;
}


int main(int argc, char *argv[])
{
    


    generate_context = 1;
    verbose = 2;
    controller.parameters_folder = "keys_exp1";
    uint32_t  multDepth = 25;   

    CryptoContext<DCRTPoly> context;

    KeyPair<DCRTPoly> key_pair;


    CCParams<CryptoContextCKKSRNS> parameters;
    parameters.SetRingDim(1 << 16);   
    parameters.SetSecretKeyDist(SPARSE_TERNARY);
    parameters.SetSecurityLevel(lbcrypto::HEStd_128_classic);
    parameters.SetNumLargeDigits(2);
    parameters.SetBatchSize(1 << 14);  

    vector<uint32_t> level_budget = {4, 4};
    level_budget = vector<uint32_t>();           

    level_budget.push_back(3);          
    level_budget.push_back(3);          

    parameters.SetScalingModSize(38);         
    parameters.SetScalingTechnique(FLEXIBLEAUTO);   
    parameters.SetFirstModSize(42);           
    parameters.SetMultiplicativeDepth(multDepth);

    context = GenCryptoContext(parameters); 



    context->Enable(PKE);          
    context->Enable(KEYSWITCH);    
    context->Enable(LEVELEDSHE);   
    context->Enable(ADVANCEDSHE);   
    context->Enable(FHE);          

    key_pair = context->KeyGen();       

    context->EvalMultKeyGen(key_pair.secretKey);   

    cout << "Generated." << endl;

    std::cout << "CKKS scheme is using ring dimension " << context->GetRingDimension() << std::endl << std::endl;

    context->EvalRotateKeyGen(key_pair.secretKey, {1, -2});

    std::vector<double> x_1 = {1.0, 1.1, 1.2, 1.3, 1.4,
                               1.5, 1.6, 1.7, 1.8, 1.9, 
                               1.10,1.11,1.12,1.13,1.14,
                               1.15,1.16,1.17,1.18,1.19,
                               1.20,1.21,1.22,1.23,1.24};
 
    std::vector<double> x_2 = {2.0, 2.1, 2.2, 2.3, 2.4,
                               2.5, 2.6, 2.7, 2.8, 2.9, 
                               2.10,2.11,2.12,2.13,2.14,
                               2.15,2.16,2.17,2.18,2.19,
                               2.20,2.21,2.22,2.23,2.24};

    std::vector<double> x_3 = {3.0, 3.1, 3.2, 3.3, 3.4,
                               3.5, 3.6, 3.7, 3.8, 3.9, 
                               3.10,3.11,3.12,3.13,3.14,
                               3.15,3.16,3.17,3.18,3.19,
                               3.20,3.21,3.22,3.23,3.24};

    std::vector<double> x_4 = {0.0, 0.0, 0.0, 0.0, 0.0, 
                               0.0, 0.0, 0.0, 0.0, 0.0,  
                               0.0, 0.0, 0.0, 0.0, 0.0, 
                               0.0, 0.0, 0.0, 0.0, 0.0, 
                               0.0, 0.0, 0.0, 0.0, 0.0};

    std::vector<double> kernel = { 1, 2, 3,
                                   4, 5, 6,
                                   7, 8, 9 };
    
    std::vector<double> kernel_0 = {5.0, 5.0, 5.0, 5.0, 5.0,
                                    5.0, 5.0, 5.0, 5.0, 5.0, 
                                    5.0, 5.0, 5.0, 5.0, 5.0,
                                    5.0, 5.0, 5.0, 5.0, 5.0,
                                    5.0, 5.0, 5.0, 5.0, 5.0};
    
    std::vector<double> kernel_1 = {6.0, 6.0, 6.0, 6.0, 0.0,
                                    6.0, 6.0, 6.0, 6.0, 0.0, 
                                    6.0, 6.0, 6.0, 6.0, 0.0,
                                    6.0, 6.0, 6.0, 6.0, 0.0,
                                    6.0, 6.0, 6.0, 6.0, 0.0};
    
    std::vector<double> kernel_n1 = {0.0, 4.0, 4.0, 4.0, 4.0,
                                     0.0, 4.0, 4.0, 4.0, 4.0, 
                                     0.0, 4.0, 4.0, 4.0, 4.0,
                                     0.0, 4.0, 4.0, 4.0, 4.0,
                                     0.0, 4.0, 4.0, 4.0, 4.0};

    std::vector<double> kernel_4 = {0.0, 7.0, 7.0, 7.0, 7.0,
                                    0.0, 7.0, 7.0, 7.0, 7.0, 
                                    0.0, 7.0, 7.0, 7.0, 7.0,
                                    0.0, 7.0, 7.0, 7.0, 7.0,
                                    0.0, 0.0, 0.0, 0.0, 0.0};
    
    std::vector<double> kernel_n4 = {0.0, 0.0, 0.0, 0.0, 0.0,
                                     3.0, 3.0, 3.0, 3.0, 0.0, 
                                     3.0, 3.0, 3.0, 3.0, 0.0,
                                     3.0, 3.0, 3.0, 3.0, 0.0,
                                     3.0, 3.0, 3.0, 3.0, 0.0};

    std::vector<double> kernel_5 = {8.0, 8.0, 8.0, 8.0, 8.0,
                                    8.0, 8.0, 8.0, 8.0, 8.0, 
                                    8.0, 8.0, 8.0, 8.0, 8.0,
                                    8.0, 8.0, 8.0, 8.0, 8.0,
                                    0.0, 0.0, 0.0, 0.0, 0.0};
    
    std::vector<double> kernel_n5 = {0.0, 0.0, 0.0, 0.0, 0.0,
                                     2.0, 2.0, 2.0, 2.0, 2.0, 
                                     2.0, 2.0, 2.0, 2.0, 2.0,
                                     2.0, 2.0, 2.0, 2.0, 2.0,
                                     2.0, 2.0, 2.0, 2.0, 2.0};   

    std::vector<double> kernel_6 = {9.0, 9.0, 9.0, 9.0, 0.0,
                                    9.0, 9.0, 9.0, 9.0, 0.0, 
                                    9.0, 9.0, 9.0, 9.0, 0.0,
                                    9.0, 9.0, 9.0, 9.0, 0.0,
                                    0.0, 0.0, 0.0, 0.0, 0.0};
    
    std::vector<double> kernel_n6 = {0.0, 0.0, 0.0, 0.0, 0.0,
                                     0.0, 1.0, 1.0, 1.0, 1.0, 
                                     0.0, 1.0, 1.0, 1.0, 1.0,
                                     0.0, 1.0, 1.0, 1.0, 1.0,
                                     0.0, 1.0, 1.0, 1.0, 1.0};


    Plaintext plaintextKernel_0 = context->MakeCKKSPackedPlaintext(kernel_0);
    Plaintext plaintextKernel_1 = context->MakeCKKSPackedPlaintext(kernel_1);
    Plaintext plaintextKernel_n1 = context->MakeCKKSPackedPlaintext(kernel_n1);
    Plaintext plaintextKernel_4 = context->MakeCKKSPackedPlaintext(kernel_4);
    Plaintext plaintextKernel_n4 = context->MakeCKKSPackedPlaintext(kernel_n4);
    Plaintext plaintextKernel_5 = context->MakeCKKSPackedPlaintext(kernel_5);
    Plaintext plaintextKernel_n5 = context->MakeCKKSPackedPlaintext(kernel_n5);
    Plaintext plaintextKernel_6 = context->MakeCKKSPackedPlaintext(kernel_6);
    Plaintext plaintextKernel_n6 = context->MakeCKKSPackedPlaintext(kernel_n6);

    std::vector<Plaintext> plaintextKernels = {
        plaintextKernel_0, plaintextKernel_1, plaintextKernel_n1,
        plaintextKernel_4, plaintextKernel_n4, plaintextKernel_5,
        plaintextKernel_n5, plaintextKernel_6, plaintextKernel_n6
    };
    

    std::vector<double> combinedVector_horizontal;
    combinedVector_horizontal.insert(combinedVector_horizontal.end(), x_1.begin(), x_1.end());
    combinedVector_horizontal.insert(combinedVector_horizontal.end(), x_2.begin(), x_2.end());
    combinedVector_horizontal.insert(combinedVector_horizontal.end(), x_3.begin(), x_3.end());

    Plaintext packedPlaintext_horizontal = context->MakeCKKSPackedPlaintext(combinedVector_horizontal);

    Ciphertext<DCRTPoly> encryptedCombined_horizontal = context->Encrypt(key_pair.publicKey, packedPlaintext_horizontal);

    std::cout << "Encrypted horizontal combined vector." << std::endl;
    Plaintext result_combinedVector_horizontal;
    context->Decrypt(key_pair.secretKey, encryptedCombined_horizontal, &result_combinedVector_horizontal);
    result_combinedVector_horizontal->SetLength(combinedVector_horizontal.size());
    std::cout << "Horizontal dense packing result: " << result_combinedVector_horizontal << std::endl;


    std::vector<double> combinedVector_space(100, 0.0);

    int idx1 = 0, idx2 = 0, idx3 = 0, idx4 = 0;


    for (int i = 0; i < 10; i += 2) { 
        for (int j = 0; j < 10; j += 2) {

            combinedVector_space[i * 10 + j] = x_1[idx1++];
            combinedVector_space[i * 10 + (j + 1)] = x_2[idx2++];


            combinedVector_space[(i + 1) * 10 + j] = x_3[idx3++];
            combinedVector_space[(i + 1) * 10 + (j + 1)] = x_4[idx4++];
        }
    }

    std::cout << "Combined Matrix:" << std::endl;
    for (int i = 0; i < 10; ++i) {
        for (int j = 0; j < 10; ++j) {
            std::cout << combinedVector_space[i * 10 + j] << "\t";
        }
        std::cout << std::endl;
    }

    Plaintext packedPlaintext_space = context->MakeCKKSPackedPlaintext(combinedVector_space);

    Ciphertext<DCRTPoly> encryptedCombined_space = context->Encrypt(key_pair.publicKey, packedPlaintext_space);
    std::cout << "Encrypted space combined vector." << std::endl;

    Plaintext result_combinedVector_space;
    context->Decrypt(key_pair.secretKey, encryptedCombined_space, &result_combinedVector_space);
    result_combinedVector_space->SetLength(combinedVector_space.size());
    std::cout << "Spatial dense packing result: " << result_combinedVector_space << std::endl;

    
    

}
